import React from "react";
import { render, screen } from "@testing-library/react";
import Restaurants from "../pages/restaurants";
import "@testing-library/jest-dom/extend-expect";
import "@testing-library/jest-dom";

test("not empty", () => {
  render(<Restaurants />);
  screen.debug();
  expect(screen.getByText("ลืมเคี้ยว")).toBeInTheDocument();
});
